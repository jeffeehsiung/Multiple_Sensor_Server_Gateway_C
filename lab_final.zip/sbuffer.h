/**
 * \author Jeffee Hsiung
 */

#ifndef _SBUFFER_H_
#define _SBUFFER_H_


#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <ctype.h>
#include <stdbool.h>
#include "config.h"

#define SBUFFER_FAILURE -1
#define SBUFFER_SUCCESS 0
#define SBUFFER_NO_DATA 1
#define SBUFFER_END 2
#define CONSUMER_A 0
#define CONSUMER_B 1


/**
 * a structure to keep track of the buffer
 */
typedef struct sbuffer_node {
    sensor_data_t data;         /**< the sensor data */
    struct sbuffer_node* next;  /**< a pointer to the next node in the buffer */
    bool read_by_a;
    bool read_by_b;
}sbuffer_node_t;

typedef struct sbuffer {
    sbuffer_node_t* head;       /**< a pointer to the first node in the buffer */
    sbuffer_node_t* tail;       /**< a pointer to the last node in the buffer */
    bool end_of_stream;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
}sbuffer_t;

/**
 * Allocates and initializes a new shared buffer
 * \param buffer a double pointer to the buffer that needs to be initialized
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occurred
 */
int sbuffer_init(sbuffer_t **buffer);

/**
 * All allocated resources are freed and cleaned up
 * \param buffer a double pointer to the buffer that needs to be freed
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occurred
 */
int sbuffer_free(sbuffer_t **buffer);

/**
 * Removes the first sensor data in 'buffer' (at the 'head') and returns this sensor data as '*data'
 * If 'buffer' is empty, the function doesn't block until new sensor data becomes available but returns SBUFFER_NO_DATA
 * \param buffer a pointer to the buffer that is used
 * \param data a pointer to pre-allocated sensor_data_t space, the data will be copied into this structure. No new memory is allocated for 'data' in this function.
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occurred
 */
int sbuffer_remove(sbuffer_t *buffer, sensor_data_t* data, int consumer_id);

/**
 * Inserts the sensor data in 'data' at the end of 'buffer' (at the 'tail')
 * \param buffer a pointer to the buffer that is used
 * \param data a pointer to sensor_data_t data, that will be copied into the buffer
 * \return SBUFFER_SUCCESS on success and SBUFFER_FAILURE if an error occured
*/
int sbuffer_insert(sbuffer_t *buffer, sensor_data_t *data);

/**
 * set flags to check EOF
*/
void sbuffer_set_end(sbuffer_t* buffer, bool end);


#endif  //_SBUFFER_H_

